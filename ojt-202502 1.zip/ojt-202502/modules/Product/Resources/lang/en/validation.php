<?php

return [
    'price_field_is_required' => 'The price field is required',
];
