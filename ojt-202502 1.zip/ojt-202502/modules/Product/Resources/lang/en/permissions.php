<?php

return [
    'index' => 'Index Products',
    'create' => 'Create Products',
    'edit' => 'Edit Products',
    'destroy' => 'Delete Products',
];
