<?php

return [
    'name' => 'Option',
];
