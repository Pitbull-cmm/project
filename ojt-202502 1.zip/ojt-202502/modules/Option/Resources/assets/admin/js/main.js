import Option from "./Option";

if ($("#option-create-form, #option-edit-form").length !== 0) {
    new Option();
}
