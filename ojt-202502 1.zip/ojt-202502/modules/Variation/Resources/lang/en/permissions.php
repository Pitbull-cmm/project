<?php

return [
    'variations' => [
        'index' => 'Index Variations',
        'create' => 'Create Variations',
        'edit' => 'Edit Variations',
        'destroy' => 'Delete Variations',
    ],
];
