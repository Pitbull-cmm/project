<div class="form-group">
    <div class="col-md-10 {{ ($buttonOffset ?? true) ? 'col-md-offset-2' : '' }}">
        <button type="submit" class="btn btn-primary" data-loading>
            {{ trans('admin::admin.buttons.save') }}
        </button>
    </div>
</div>
