<?php

namespace App;

class Ecommerce
{
    /**
     * The Ecommerce version.
     *
     * @var string
     */
    const VERSION = '1.0.1';
}
