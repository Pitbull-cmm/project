<?php

namespace Modules\Brand\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Modules\Brand\Entities\Brand;
use Modules\Brand\Http\Requests\SaveBrandRequest;

class BrandController
{
    protected $model;

    protected string $label = 'brand::brands.brand';

    protected string $viewPath = 'brand::admin.brands';

    protected $validation = SaveBrandRequest::class;

    public function __construct(Brand $brand)
    {
        $this->model = $brand;
    }

    public function index(Request $request)
    {
        [$sortBy, $sortOrder, $perPage, $search] = [
            $request->get('sort_by', 'created_at'),
            $request->get('sort', SORT_DIRECTIONS),
            $request->get('per_page', PAGE_LIMIT),
            $request->get('keyword', '')
        ];

        //Query
        $brands = $this->model->query()->when($search, function ($query) use ($search) {
            return $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%");
            });
        })
        ->when($sortBy && $sortOrder, function ($query) use ($sortBy, $sortOrder) {
            return $query->orderBy($sortBy, $sortOrder);
        })
        ->paginate($perPage);

        return view("{$this->viewPath}.index", compact('brands'));
    }

    public function create()
    {
        return view("{$this->viewPath}.create", ['brand' => $this->model]);
    }

    public function store()
    {
        $entity = $this->model->create(
            $this->getRequest('store')->except(array_keys(request()->query()))
        );
        if (method_exists($this, 'redirectTo')) {
            return $this->redirectTo($entity);
        }
        DB::commit();
        return redirect()->route("admin.brands")
            ->withSuccess(trans('admin::messages.resource_created', ['resource' => trans($this->label)]));
    }

    public function edit($id)
    {
        $brand = $this->model->findOrFail($id);
        return view("{$this->viewPath}.edit", compact('brand'));
    }

    public function update($id)
    {
        $entity = $this->model->findOrFail($id);
        $entity->update(
            $this->getRequest('update')->except(array_keys(request()->query()))
        );
        return redirect()->route("admin.brands")
            ->withSuccess(trans('admin::messages.resource_updated', ['resource' => trans($this->label)]));
    }

    public function destroy(Request $request)
    {
        DB::beginTransaction();
        try {
            $ids = json_decode($request->input('ids'));
            $this->model->withoutGlobalScope('active')->whereIn('id', $ids)->delete();
            DB::commit();
            return redirect()->route('admin.brands')->withSuccess(trans('admin::messages.resource_deleted', ['resource' => trans($this->label)]));
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->route('admin.brands')->with([
                'error' => 'Đã xảy ra lỗi khi trong quá trình xoá: ' . $e->getMessage(),
            ]);
        }
    }

    protected function getRequest(string $action): Request
    {
        return match (true) {
            !isset($this->validation) => request(),
            isset($this->validation[$action]) => resolve($this->validation[$action]),
            default => resolve($this->validation),
        };
    }
}
