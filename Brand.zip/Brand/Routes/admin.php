<?php

use Illuminate\Support\Facades\Route;
use Modules\Brand\Http\Controllers\Admin\BrandController;

Route::group(['prefix' => 'brands'], function () {
    Route::get('/', [BrandController::class, 'index'])->name('admin.brands');
    Route::post('/', [BrandController::class, 'store'])->name('admin.brands.store');
    Route::get('create', [BrandController::class, 'create'])->name('admin.brands.create');
    Route::get('{id}/edit', [BrandController::class, 'edit'])->name('admin.brands.edit');
    Route::put('{id}', [BrandController::class, 'update'])->name('admin.brands.update');
    Route::delete('{ids?}', [BrandController::class, 'destroy'])->name('admin.brands.destroy');
});
