@extends('admin::layout')

@component('admin::components.page.header')
    @slot('title', trans('admin::resource.create', ['resource' => trans('brand::brands.brand')]))

    <li><a href="{{ route('admin.brands') }}">{{ trans('brand::brands.brands') }}</a></li>
    <li class="active">{{ trans('admin::resource.create', ['resource' => trans('brand::brands.brand')]) }}</li>
@endcomponent

@section('content')
    <form method="POST" action="{{ route('admin.brands.store') }}" class="form-horizontal" id="brand-create-form" novalidate>
        {{ csrf_field() }}

        <div class="accordion-content clearfix">
            <div class="col-lg-3 col-md-4">
                <div class="accordion-box">
                    <div class="panel-group" id="BrandTabs">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">
                                    <a>
                                        {{ trans('brand::brands.tabs.group.brand_information') }}
                                        @if ($errors->any())
                                            <i class="fa fa-exclamation-circle" aria-hidden="true"></i>
                                        @endif
                                    </a>
                                </h4>
                            </div>

                            <div id="brand_information" class="panel-collapse collapse in">
                                <div class="panel-body">
                                    <ul class="accordion-tab nav nav-tabs">
                                        <li class="active {{ $errors->has("name") ? 'has-error' : '' }}">
                                            <a href="#general" data-toggle="tab">
                                                {{ trans('brand::brands.tabs.general') }}
                                                @if ($errors->has('name'))
                                                    <i class="fa fa-exclamation-circle" aria-hidden="true"></i>
                                                @endif
                                            </a>
                                        </li>
                                        <li class=" ">
                                            <a href="#images" data-toggle="tab">{{ trans('brand::brands.tabs.images') }}</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-9 col-md-8">
                <div class="accordion-box-content">
                    <div class="tab-content clearfix">
                        <div class="tab-pane fade in active" id="general">
                            <h4 class="tab-content-title">{{ trans('brand::brands.tabs.general') }}</h4>
                            @include('brand::admin.brands.tabs.general')
                        </div>

                        <div class="tab-pane fade in " id="images">
                            <h4 class="tab-content-title">Images</h4>
                            @include('brand::admin.brands.tabs.images')
                        </div>

                        <div class="form-group">
                            <div class="col-md-10 col-md-offset-2">
                                <button type="submit" class="btn btn-primary" data-loading="">
                                    Save
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
@endsection

@include('brand::admin.brands.partials.shortcuts')

@push('globals')
    @vite([
        'modules/Brand/Resources/assets/admin/js/main.js',
        'modules/Media/Resources/assets/admin/sass/main.scss',
        'modules/Media/Resources/assets/admin/js/main.js',
    ])
@endpush
