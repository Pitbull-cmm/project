@extends('admin::layout')

@component('admin::components.page.header')
    @slot('title', trans('brand::brands.brands'))

    <li class="active">{{ trans('brand::brands.brands') }}</li>
@endcomponent

@component('admin::components.page.index_table')
    @slot('buttons', ['create'])
    @slot('resource', 'brands')
    @slot('name', trans('brand::brands.brand'))

    @component('admin::components.table')
        @slot('thead')
            <tr>
                @php
                    $sortBy = request()->get('sort_by', 'created_at');
                    $sort = request()->get('sort', SORT_DIRECTIONS);
                @endphp

                @include('admin::partials.table.select_all')
                <th style="width: 10%;" class="dt-orderable-asc dt-orderable-desc @if($sortBy === 'id') {{ $sort === 'asc' ? 'dt-ordering-asc' : 'dt-ordering-desc' }} @endif">
                    <a href="{{ request()->fullUrlWithQuery(['sort_by' => 'id', 'sort' => sort_directions($sort)]) }}">
                        <span class="dt-column-title">{{ trans('admin::admin.table.id') }}</span>
                        <span class="dt-column-order"></span>
                    </a>
                </th>
                <th style="width: 90px;" class="dt-orderable-none">{{ trans('brand::brands.table.logo') }}</th>
                <th style="width: 44%;" class="dt-orderable-asc dt-orderable-desc @if($sortBy === 'name') {{ $sort === 'asc' ? 'dt-ordering-asc' : 'dt-ordering-desc' }} @endif">
                    <a href="{{ request()->fullUrlWithQuery(['sort_by' => 'name', 'sort' => sort_directions($sort)]) }}">
                        <span class="dt-column-title">{{ trans('brand::brands.table.name') }}</span>
                        <span class="dt-column-order"></span>
                    </a>
                </th>
                <th class="dt-orderable-asc dt-orderable-desc @if($sortBy === 'is_active') {{ $sort === 'asc' ? 'dt-ordering-asc' : 'dt-ordering-desc' }} @endif">
                    <a href="{{ request()->fullUrlWithQuery(['sort_by' => 'is_active', 'sort' => sort_directions($sort)]) }}">
                        <span class="dt-column-title">{{ trans('admin::admin.table.status') }}</span>
                        <span class="dt-column-order"></span>
                    </a>
                </th>
                <th class="dt-orderable-asc dt-orderable-desc @if($sortBy === 'created_at') {{ $sort === 'asc' ? 'dt-ordering-asc' : 'dt-ordering-desc' }} @endif">
                    <a href="{{ request()->fullUrlWithQuery(['sort_by' => 'created_at', 'sort' => sort_directions($sort)]) }}">
                        <span class="dt-column-title">{{ trans('admin::admin.table.created') }}</span>
                        <span class="dt-column-order"></span>
                    </a>
                </th>
            </tr>
        @endslot
        @slot('tbody')
            @if (!empty($brands))
                @foreach ($brands as $brand)
                    <tr class="clickable-row">
                        <td>
                            <div class="checkbox">
                                <input
                                    type="checkbox"
                                    class="select-row"
                                    name="ids[]"
                                    id="brand-{{ $brand->id }}"
                                    value="{{ $brand->id }}">
                                <label for="brand-{{ $brand->id }}"></label>
                            </div>
                        </td>
                        <td class="dt-type-numeric">{{ $brand->id }}</td>
                        <td>
                            <div class="thumbnail-holder">
                                @if ($brand->getLogoAttribute()->path)
                                    <img src="{{ $brand->getLogoAttribute()->path }}" alt="{{ $brand->name ?? '' }}">
                                @else
                                    <i class="fa fa-picture-o"></i>
                                @endif
                            </div>
                        </td>
                        <td>
                            <a href="{{ route('admin.brands.edit', $brand->id) }}">{{ $brand->name ?? '' }}</a>
                        </td>
                        <td>
                            <span class="badge {{ $brand->is_active ? 'badge-success' : 'badge-danger' }}">
                            {{ $brand->is_active ? 'Active' : 'UnActive' }}
                        </span>
                        </td>
                        <td>
                            @if ($brand->created_at)
                                <span data-toggle="tooltip" title="{{ $brand->created_at }}">{{  $brand->created_at->diffForHumans() }}</span>
                            @endif
                        </td>
                    </tr>
                @endforeach
            @else
                <tr>
                    <td colspan="6" class="dt-empty">No data available in table</td>
                </tr>
            @endif
        @endslot
        @slot('pagination', $brands)
    @endcomponent
@endcomponent

@push('scripts')
    <script type="module">
        Ecommerce.data['route.delete'] = route('admin.brands.destroy');
    </script>
@endpush
