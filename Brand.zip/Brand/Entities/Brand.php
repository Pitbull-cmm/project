<?php

namespace Modules\Brand\Entities;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Modules\Media\Eloquent\HasMedia;
use Modules\Media\Entities\File;
use Modules\Product\Entities\Product;

class Brand extends Model
{
    use HasFactory, HasMedia;

    protected $fillable = [
        'name',
        'is_active',
        'logo',
        'banner',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public static function findBySlug($slug)
    {
        return self::where('slug', $slug)->firstOrNew([]);
    }

    public function products(): HasMany
    {
        return $this->hasMany(Product::class);
    }

    public function getLogoAttribute()
    {
        return $this->files->where('pivot.zone', 'logo')->first() ?: new File;
    }

    /**
     * Get the brand's banner.
     *
     * @return File
     */
    public function getBannerAttribute()
    {
        return $this->files->where('pivot.zone', 'banner')->first() ?: new File;
    }
}
