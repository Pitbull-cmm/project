<?php

return [
    'name' => 'Brand',
];
